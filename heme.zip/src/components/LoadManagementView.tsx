import React, { useState, useEffect } from 'react';
import { Athlete, ACWRTimelinePoint } from '../types';
import { generate28DayACWRData } from '../mockData';
import {
  Layers,
  AlertOctagon,
  TrendingUp,
  Activity,
  Calendar,
  Sparkles,
  Info,
  CheckCircle2,
  Zap,
  Sliders
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceArea,
  ReferenceLine
} from 'recharts';

interface LoadManagementViewProps {
  athletes: Athlete[];
  selectedAthleteId?: string;
  onOpenLogSession: (athleteId?: string) => void;
  onOpenAICopilotForACWR: (athlete: Athlete, acwrData: ACWRTimelinePoint[]) => void;
}

export const LoadManagementView: React.FC<LoadManagementViewProps> = ({
  athletes,
  selectedAthleteId,
  onOpenLogSession,
  onOpenAICopilotForACWR
}) => {
  const [activeAthleteId, setActiveAthleteId] = useState<string>(
    selectedAthleteId || athletes[0]?.id || 'ath-1'
  );

  useEffect(() => {
    if (selectedAthleteId) {
      setActiveAthleteId(selectedAthleteId);
    }
  }, [selectedAthleteId]);

  const activeAthlete = athletes.find(a => a.id === activeAthleteId) || athletes[0];
  const acwrTimeline = generate28DayACWRData(activeAthlete);

  const latestPoint = acwrTimeline[acwrTimeline.length - 1] || {
    acuteLoad: 500,
    chronicLoad: 450,
    acwr: 1.11,
    sRPE: 450
  };

  const getACWRZoneLabel = (acwr: number) => {
    if (acwr > 1.5) {
      return {
        label: 'HIGH RISK (SPIKE)',
        color: 'text-rose-500 bg-rose-500/10 border-rose-500/20',
        desc: 'Acute workload is >150% of chronic baseline. High injury vulnerability.'
      };
    }
    if (acwr > 1.3) {
      return {
        label: 'ELEVATED CAUTION',
        color: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
        desc: 'Workload is escalating. Monitor recovery and fatigue markers.'
      };
    }
    if (acwr >= 0.8) {
      return {
        label: 'SWEET SPOT (OPTIMAL)',
        color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
        desc: 'Optimal workload ratio for fitness progression & injury protection.'
      };
    }
    return {
      label: 'UNDERLOADED',
      color: 'text-slate-500 bg-slate-500/10 border-slate-500/20',
      desc: 'Workload below baseline. Risk of detraining or unreadiness.'
    };
  };

  const currentZone = getACWRZoneLabel(activeAthlete.currentACWR);

  return (
    <div className="space-y-6">
      {/* View Header & Athlete Switcher */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-500">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-900 dark:text-white">
                Acute-to-Chronic Workload Ratio (ACWR) Engine
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                7-day rolling Acute Load vs 28-day Chronic Load based on Session RPE (sRPE)
              </p>
            </div>
          </div>
        </div>

        {/* Athlete Picker */}
        <div className="flex items-center gap-3 shrink-0">
          <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
            Select Athlete:
          </label>
          <select
            value={activeAthleteId}
            onChange={e => setActiveAthleteId(e.target.value)}
            className="text-xs font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
          >
            {athletes.map(a => (
              <option key={a.id} value={a.id}>
                {a.name} ({a.squad}) - ACWR: {a.currentACWR}
              </option>
            ))}
          </select>

          <button
            onClick={() => onOpenLogSession(activeAthleteId)}
            className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-md shadow-teal-500/20 transition flex items-center gap-1.5"
          >
            <Activity className="w-4 h-4" />
            Log Session sRPE
          </button>
        </div>
      </div>

      {/* Athlete Status & Gauge Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Selected Athlete Profile Summary */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <img
            src={activeAthlete.avatarUrl}
            alt={activeAthlete.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-teal-500/30"
          />
          <div>
            <h2 className="font-bold text-base text-slate-900 dark:text-white">
              {activeAthlete.name}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {activeAthlete.position} • {activeAthlete.squad}
            </p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                Readiness: {activeAthlete.readinessScore}%
              </span>
            </div>
          </div>
        </div>

        {/* ACWR Ratio Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>CURRENT ACWR RATIO</span>
            <Zap className="w-4 h-4 text-teal-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              {activeAthlete.currentACWR}
            </span>
            <span className="text-xs font-semibold text-slate-400">Ratio</span>
          </div>
          <div className={`mt-2 px-2.5 py-1 rounded-lg border text-[11px] font-bold ${currentZone.color}`}>
            {currentZone.label}
          </div>
        </div>

        {/* 7-Day Acute Load */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>ACUTE LOAD (7-DAY AVG)</span>
            <Activity className="w-4 h-4 text-teal-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              {latestPoint.acuteLoad}
            </span>
            <span className="text-xs font-semibold text-slate-400">AU / day</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Recent fatigue building blocks
          </p>
        </div>

        {/* 28-Day Chronic Load */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>CHRONIC LOAD (28-DAY AVG)</span>
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              {latestPoint.chronicLoad}
            </span>
            <span className="text-xs font-semibold text-slate-400">AU / day</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Historical fitness capacity baseline
          </p>
        </div>
      </div>

      {/* 28-Day ACWR Timeline Interactive Chart */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-teal-500" />
              28-Day Workload Trend & Sweet Spot Band (0.8 - 1.3)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bars = Daily sRPE Load | Teal Line = ACWR Ratio | Shaded Area = Optimal Zone
            </p>
          </div>

          <button
            onClick={() => onOpenAICopilotForACWR(activeAthlete, acwrTimeline)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white shadow-md transition shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            AI Workload Advisory
          </button>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={acwrTimeline} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis yAxisId="load" orientation="left" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis
                yAxisId="acwr"
                orientation="right"
                domain={[0, 2.2]}
                tick={{ fontSize: 11, fill: '#10b981' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '12px',
                  color: '#fff'
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />

              {/* Sweet Spot Band (0.8 - 1.3) */}
              {React.createElement(ReferenceArea as any, {
                yAxisId: "acwr",
                y1: 0.8,
                y2: 1.3,
                fill: "#10b981",
                fillOpacity: 0.1,
                label: { value: 'Optimal Sweet Spot (0.8 - 1.3)', fill: '#10b981', fontSize: 10 }
              })}

              {/* Danger Line > 1.5 */}
              <ReferenceLine
                yAxisId="acwr"
                y={1.5}
                stroke="#f43f5e"
                strokeDasharray="4 4"
                label={{ value: 'Spike Risk Zone (>1.5)', fill: '#f43f5e', fontSize: 10 }}
              />

              <Bar
                yAxisId="load"
                dataKey="sRPE"
                name="Daily sRPE (AU)"
                fill="#3b82f6"
                opacity={0.6}
                radius={[4, 4, 0, 0]}
              />

              <Line
                yAxisId="acwr"
                type="monotone"
                dataKey="acwr"
                name="ACWR Ratio"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ r: 4, fill: '#10b981' }}
                activeDot={{ r: 7 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Educational Explanation Box */}
      <div className="bg-slate-50 dark:bg-slate-900/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-2">
        <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-sm">
          <Info className="w-4 h-4 text-teal-500" />
          Understanding the ACWR Sports Science Engine
        </div>
        <p>
          The <strong>Acute-to-Chronic Workload Ratio (ACWR)</strong> models the relationship between recent training load (Acute = 7-day rolling average) and historical fitness capacity (Chronic = 28-day rolling average).
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="font-bold text-emerald-600 dark:text-emerald-400">Sweet Spot (0.8 - 1.3)</span>
            <p className="mt-1 text-[11px]">Calculated as optimal fitness building with minimal injury risk (~5%).</p>
          </div>
          <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="font-bold text-amber-600 dark:text-amber-400">Caution Zone (1.3 - 1.5)</span>
            <p className="mt-1 text-[11px]">Training load is accelerating faster than recovery adaptation capability.</p>
          </div>
          <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="font-bold text-rose-600 dark:text-rose-400">Danger Zone (&gt; 1.5)</span>
            <p className="mt-1 text-[11px]">Workload spike exponentially increases soft tissue injury risk (up to 21-49%).</p>
          </div>
        </div>
      </div>
    </div>
  );
};
