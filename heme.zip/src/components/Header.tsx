import React from 'react';
import { SquadName } from '../types';
import {
  Activity,
  Calendar,
  Sparkles,
  UserPlus,
  ClipboardList,
  Sun,
  Moon,
  Layers,
  Dumbbell
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'dashboard' | 'load' | 'programs' | 'athletes';
  setCurrentTab: (tab: 'dashboard' | 'load' | 'programs' | 'athletes') => void;
  selectedSquad: SquadName | 'All';
  setSelectedSquad: (squad: SquadName | 'All') => void;
  onOpenSurvey: () => void;
  onOpenLogSession: () => void;
  onOpenAICopilot: () => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  selectedSquad,
  setSelectedSquad,
  onOpenSurvey,
  onOpenLogSession,
  onOpenAICopilot,
  isDarkMode,
  setIsDarkMode
}) => {
  const squads: (SquadName | 'All')[] = [
    'All',
    'Rugby First XV',
    'Track & Field',
    'Basketball Varsity',
    'Soccer Premier'
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/20 text-white font-black tracking-widest text-lg">
              <Activity className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xl tracking-tight text-slate-900 dark:text-white">
                  HEME
                </span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  PRO S&C
                </span>
              </div>

            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'dashboard'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Activity className="w-4 h-4" />
              Dashboard
            </button>

            <button
              onClick={() => setCurrentTab('load')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'load'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4" />
              ACWR & Load Management
            </button>

            <button
              onClick={() => setCurrentTab('programs')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'programs'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Dumbbell className="w-4 h-4" />
              Microcycles
            </button>

            <button
              onClick={() => setCurrentTab('athletes')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentTab === 'athletes'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              Roster
            </button>
          </nav>

          {/* Right Controls & Quick Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Squad Selector */}
            <select
              value={selectedSquad}
              onChange={(e) => setSelectedSquad(e.target.value as SquadName | 'All')}
              className="text-xs font-medium bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {squads.map(sq => (
                <option key={sq} value={sq}>{sq === 'All' ? '⚡ All Squads' : sq}</option>
              ))}
            </select>

            {/* Quick Action Buttons */}
            <button
              onClick={onOpenSurvey}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 transition"
              title="Log Daily Wellness Survey"
            >
              <ClipboardList className="w-3.5 h-3.5 text-emerald-500" />
              Daily Survey
            </button>

            <button
              onClick={onOpenLogSession}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition"
              title="Log sRPE Session"
            >
              <Activity className="w-3.5 h-3.5" />
              Log sRPE
            </button>

            <button
              onClick={onOpenAICopilot}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white shadow-md shadow-teal-500/20 transition"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span className="hidden xs:inline">AI Copilot</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800 transition"
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Bar */}
      <div className="flex md:hidden border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 px-2 py-1.5 justify-around">
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`px-3 py-1 text-xs font-medium rounded-md ${currentTab === 'dashboard' ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-600 dark:text-slate-400'}`}
        >
          Dashboard
        </button>
        <button
          onClick={() => setCurrentTab('load')}
          className={`px-3 py-1 text-xs font-medium rounded-md ${currentTab === 'load' ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-600 dark:text-slate-400'}`}
        >
          ACWR Load
        </button>
        <button
          onClick={() => setCurrentTab('programs')}
          className={`px-3 py-1 text-xs font-medium rounded-md ${currentTab === 'programs' ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-600 dark:text-slate-400'}`}
        >
          Microcycles
        </button>
        <button
          onClick={() => setCurrentTab('athletes')}
          className={`px-3 py-1 text-xs font-medium rounded-md ${currentTab === 'athletes' ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-600 dark:text-slate-400'}`}
        >
          Roster
        </button>
      </div>
    </header>
  );
};
