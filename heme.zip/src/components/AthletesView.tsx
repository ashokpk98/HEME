import React, { useState } from 'react';
import { Athlete, SquadName } from '../types';
import {
  Users,
  Search,
  Activity,
  ShieldAlert,
  Dumbbell,
  ClipboardList,
  Flame,
  CheckCircle2,
  X
} from 'lucide-react';
import { generate28DayACWRData } from '../mockData';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

interface AthletesViewProps {
  athletes: Athlete[];
  squads: SquadName[];
  onOpenSurveyForAthlete: (athleteId: string) => void;
  onOpenLogSessionForAthlete: (athleteId: string) => void;
}

export const AthletesView: React.FC<AthletesViewProps> = ({
  athletes,
  squads,
  onOpenSurveyForAthlete,
  onOpenLogSessionForAthlete
}) => {
  const [selectedSquadFilter, setSelectedSquadFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectAthlete, setInspectAthlete] = useState<Athlete | null>(null);

  const filteredAthletes = athletes.filter(a => {
    const matchesSquad = selectedSquadFilter === 'All' || a.squad === selectedSquadFilter;
    const matchesSearch =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.position.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSquad && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header & Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-900 dark:text-white">
                Athlete High-Performance Roster
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Monitor individual readiness, 1RM strength benchmarks, and workload status
              </p>
            </div>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search athlete by name or position..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl pl-9 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <select
            value={selectedSquadFilter}
            onChange={e => setSelectedSquadFilter(e.target.value)}
            className="text-xs font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="All">All Squads</option>
            {squads.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Athlete Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAthletes.map(athlete => (
          <div
            key={athlete.id}
            className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 hover:border-emerald-500/40 transition"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={athlete.avatarUrl}
                  alt={athlete.name}
                  className="w-12 h-12 rounded-2xl object-cover border-2 border-slate-200 dark:border-slate-700"
                />
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    {athlete.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {athlete.position}
                  </p>
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                    {athlete.squad}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-extrabold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg">
                  {athlete.readinessScore}% Ready
                </div>
                <div className="mt-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    athlete.acwrStatus === 'Spike'
                      ? 'bg-rose-500/20 text-rose-500'
                      : athlete.acwrStatus === 'Optimal'
                      ? 'bg-emerald-500/20 text-emerald-500'
                      : 'bg-amber-500/20 text-amber-500'
                  }`}>
                    ACWR: {athlete.currentACWR}
                  </span>
                </div>
              </div>
            </div>

            {/* 1RM Strength Benchmarks */}
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 border border-slate-100 dark:border-slate-800 space-y-1.5">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider block">
                Estimated 1RM Benchmarks
              </span>
              <div className="grid grid-cols-4 gap-1 text-[11px]">
                <div>
                  <span className="text-slate-400 text-[10px] block">Squat</span>
                  <span className="font-black text-slate-900 dark:text-white">{athlete.maxes.squatKg}kg</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Bench</span>
                  <span className="font-black text-slate-900 dark:text-white">{athlete.maxes.benchKg}kg</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Deadlift</span>
                  <span className="font-black text-slate-900 dark:text-white">{athlete.maxes.deadliftKg}kg</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">P.Clean</span>
                  <span className="font-black text-slate-900 dark:text-white">{athlete.maxes.powerCleanKg}kg</span>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setInspectAthlete(athlete)}
                className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
              >
                Inspect Profile
              </button>
              <button
                onClick={() => onOpenSurveyForAthlete(athlete.id)}
                className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold"
                title="Log Daily Survey"
              >
                <ClipboardList className="w-3.5 h-3.5 text-emerald-500" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Inspect Athlete Profile Drawer / Modal */}
      {inspectAthlete && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={inspectAthlete.avatarUrl}
                  alt={inspectAthlete.name}
                  className="w-12 h-12 rounded-2xl object-cover border-2 border-emerald-500"
                />
                <div>
                  <h3 className="font-black text-lg text-slate-900 dark:text-white">
                    {inspectAthlete.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {inspectAthlete.position} • {inspectAthlete.squad}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setInspectAthlete(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Readiness & ACWR stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Readiness Score</span>
                <span className="text-xl font-black text-emerald-500">{inspectAthlete.readinessScore}%</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Current ACWR</span>
                <span className="text-xl font-black text-slate-900 dark:text-white">{inspectAthlete.currentACWR}</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Status</span>
                <span className="text-xs font-extrabold text-emerald-400">{inspectAthlete.status}</span>
              </div>
            </div>

            {/* 28-day ACWR Mini Curve */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white mb-2">
                28-Day ACWR Timeline Trend
              </h4>
              <div className="h-44 bg-slate-50 dark:bg-slate-800/40 rounded-xl p-2 border border-slate-100 dark:border-slate-800">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={generate28DayACWRData(inspectAthlete)}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                    <XAxis dataKey="date" tick={{ fontSize: 9, fill: '#94a3b8' }} />
                    <YAxis domain={[0, 2]} tick={{ fontSize: 9, fill: '#94a3b8' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', fontSize: '11px' }} />
                    <Line type="monotone" dataKey="acwr" stroke="#10b981" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {inspectAthlete.notes && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-xs text-slate-600 dark:text-slate-300">
                <strong>Coach Notes:</strong> {inspectAthlete.notes}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
