import React, { useState } from 'react';
import { Athlete } from '../types';
import { calculateReadiness } from '../mockData';
import { ClipboardList, Moon, Battery, X, Sparkles, Check } from 'lucide-react';

interface DailySurveyModalProps {
  isOpen: boolean;
  onClose: () => void;
  athletes: Athlete[];
  preselectedAthleteId?: string;
  onSubmitSurvey: (
    athleteId: string,
    surveyData: {
      sleepHours: number;
      sleepQuality: number;
      soreness: number;
      fatigue: number;
      stress: number;
      mood: number;
      notes?: string;
    }
  ) => void;
}

export const DailySurveyModal: React.FC<DailySurveyModalProps> = ({
  isOpen,
  onClose,
  athletes,
  preselectedAthleteId,
  onSubmitSurvey
}) => {
  if (!isOpen) return null;

  const [athleteId, setAthleteId] = useState<string>(
    preselectedAthleteId || athletes[0]?.id || ''
  );

  const [sleepHours, setSleepHours] = useState<number>(8.0);
  const [sleepQuality, setSleepQuality] = useState<number>(7);
  const [soreness, setSoreness] = useState<number>(3); // 1-10
  const [fatigue, setFatigue] = useState<number>(3); // 1-10
  const [stress, setStress] = useState<number>(3); // 1-10
  const [mood, setMood] = useState<number>(8); // 1-10
  const [notes, setNotes] = useState<string>('');

  const liveReadiness = calculateReadiness({
    sleepHours,
    sleepQuality,
    soreness,
    fatigue,
    stress,
    mood
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitSurvey(athleteId, {
      sleepHours,
      sleepQuality,
      soreness,
      fatigue,
      stress,
      mood,
      notes
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 my-8">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                Daily Athlete Wellness Survey
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Record morning recovery metrics & compute readiness
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Athlete Selector */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Select Athlete
            </label>
            <select
              value={athleteId}
              onChange={e => setAthleteId(e.target.value)}
              className="w-full font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {athletes.map(a => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.squad})
                </option>
              ))}
            </select>
          </div>

          {/* Live Calculated Readiness Preview Box */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/40 p-4 rounded-2xl border border-emerald-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-extrabold uppercase text-emerald-400 tracking-wider">
                Computed Readiness Score
              </span>
              <p className="text-xs text-slate-300 mt-0.5">
                {liveReadiness >= 80 ? 'Optimal state for high-intensity power' : liveReadiness >= 60 ? 'Moderate fatigue - monitor load' : 'Elevated fatigue - consider deload'}
              </p>
            </div>
            <div className="text-2xl font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30">
              {liveReadiness}%
            </div>
          </div>

          {/* Sleep Hours & Quality */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Sleep Duration</span>
                <span className="text-emerald-500 font-black">{sleepHours} hrs</span>
              </label>
              <input
                type="range"
                min="4.0"
                max="12.0"
                step="0.5"
                value={sleepHours}
                onChange={e => setSleepHours(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Sleep Quality</span>
                <span className="text-emerald-500 font-black">{sleepQuality}/10</span>
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={sleepQuality}
                onChange={e => setSleepQuality(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          {/* Soreness & Fatigue Sliders */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Muscle Soreness</span>
                <span className={`font-black ${soreness > 6 ? 'text-rose-500' : 'text-emerald-500'}`}>
                  {soreness}/10
                </span>
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={soreness}
                onChange={e => setSoreness(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>General Fatigue</span>
                <span className={`font-black ${fatigue > 6 ? 'text-rose-500' : 'text-emerald-500'}`}>
                  {fatigue}/10
                </span>
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={fatigue}
                onChange={e => setFatigue(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          {/* Stress & Mood Sliders */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Psychological Stress</span>
                <span className={`font-black ${stress > 6 ? 'text-rose-500' : 'text-emerald-500'}`}>
                  {stress}/10
                </span>
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={stress}
                onChange={e => setStress(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Mood Rating</span>
                <span className="text-emerald-500 font-black">{mood}/10</span>
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={mood}
                onChange={e => setMood(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Athlete Notes / Subjective Comments
            </label>
            <input
              type="text"
              placeholder="e.g. Left quad tightness during morning mobility..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full font-medium bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold shadow-lg shadow-emerald-600/20 transition flex items-center justify-center gap-2 text-xs"
          >
            <Check className="w-4 h-4" />
            Submit Daily Wellness Survey
          </button>
        </form>
      </div>
    </div>
  );
};
