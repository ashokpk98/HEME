import React from 'react';
import { Athlete, ACWRAlert } from '../types';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  BatteryCharging,
  Sparkles,
  ClipboardList,
  ShieldAlert,
  ArrowUpRight,
  Gauge
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  CartesianGrid
} from 'recharts';

interface DashboardViewProps {
  athletes: Athlete[];
  alerts: ACWRAlert[];
  onOpenSurveyForAthlete: (athleteId: string) => void;
  onOpenLogSessionForAthlete: (athleteId: string) => void;
  onOpenAICopilotForAlert: (alert: ACWRAlert) => void;
  onNavigateToACWR: (athleteId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  athletes,
  alerts,
  onOpenSurveyForAthlete,
  onOpenLogSessionForAthlete,
  onOpenAICopilotForAlert,
  onNavigateToACWR
}) => {
  const avgReadiness = Math.round(
    athletes.reduce((sum, a) => sum + a.readinessScore, 0) / (athletes.length || 1)
  );

  const optimalACWR = athletes.filter(a => a.acwrStatus === 'Optimal').length;
  const elevatedACWR = athletes.filter(a => a.acwrStatus === 'Elevated').length;
  const spikeACWR = athletes.filter(a => a.acwrStatus === 'Spike').length;
  const underloadedACWR = athletes.filter(a => a.acwrStatus === 'Underloaded').length;

  const chartData = athletes.map(a => ({
    name: a.name.split(' ')[0],
    readiness: a.readinessScore,
    acwr: a.currentACWR,
    squad: a.squad
  }));

  const getReadinessColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
    if (score >= 60) return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
    return 'text-rose-500 bg-rose-500/10 border-rose-500/20';
  };

  const getACWRBadge = (status: string, ratio: number) => {
    switch (status) {
      case 'Optimal':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            {ratio} Optimal
          </span>
        );
      case 'Elevated':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            {ratio} Elevated
          </span>
        );
      case 'Spike':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 animate-pulse">
            {ratio} SPIKE RISK
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20">
            {ratio} Underloaded
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Team Readiness Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Team Avg Readiness
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <BatteryCharging className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-3">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              {avgReadiness}%
            </span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
              <TrendingUp className="w-3.5 h-3.5" /> High Baseline
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                avgReadiness >= 75
                  ? 'bg-emerald-500'
                  : avgReadiness >= 60
                  ? 'bg-amber-500'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${avgReadiness}%` }}
            />
          </div>
        </div>

        {/* ACWR Sweet Spot Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              ACWR Sweet Spot (0.8-1.3)
            </span>
            <div className="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-500 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              {optimalACWR} / {athletes.length}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              athletes
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            {Math.round((optimalACWR / (athletes.length || 1)) * 100)}% of roster in safe progression zone
          </p>
        </div>

        {/* Workload Spike Risk Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              ACWR Spikes (&gt;1.5)
            </span>
            <div className={`w-8 h-8 rounded-lg ${spikeACWR > 0 ? 'bg-rose-500/10 text-rose-500 animate-pulse' : 'bg-slate-500/10 text-slate-500'} flex items-center justify-center`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-3xl font-black ${spikeACWR > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
              {spikeACWR}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              at risk
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            {spikeACWR > 0 ? 'Immediate workload modification required' : 'No critical workload spikes'}
          </p>
        </div>

        {/* Total Weekly Volume Load */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              7-Day Avg sRPE Load
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white">
              2,840
            </span>
            <span className="text-xs font-semibold text-slate-500">AU / wk</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Session RPE = Duration (min) × RPE (1-10)
          </p>
        </div>
      </div>

      {/* Critical ACWR Alerts Banner */}
      {alerts.length > 0 && (
        <div className="bg-gradient-to-r from-rose-900/30 via-slate-900 to-amber-900/30 border border-rose-500/30 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400 mt-0.5">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">
                    High Workload & Readiness Alerts ({alerts.length})
                  </h3>
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-rose-500 text-white">
                    Action Needed
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  {alerts[0].athleteName} ({alerts[0].squad}) has an ACWR ratio of{' '}
                  <strong className="text-rose-400">{alerts[0].acwr}</strong>. {alerts[0].message}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onOpenAICopilotForAlert(alerts[0])}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30 transition"
              >
                <Sparkles className="w-4 h-4" />
                AI Mitigation Strategy
              </button>
              <button
                onClick={() => onNavigateToACWR(alerts[0].athleteId)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                title="Inspect Athlete ACWR Curve"
              >
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid: Athlete Readiness Roster & Team Overview Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Athlete Readiness Cards (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Gauge className="w-4 h-4 text-emerald-500" />
                Daily Athlete Readiness & Survey Status
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Calculated from sleep duration, muscle soreness, fatigue, stress & mood
              </p>
            </div>
            <button
              onClick={() => onNavigateToACWR()}
              className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
            >
              Detailed Load Management &rarr;
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {athletes.map(athlete => {
              const readinessBadgeClass = getReadinessColor(athlete.readinessScore);
              return (
                <div
                  key={athlete.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={athlete.avatarUrl}
                        alt={athlete.name}
                        className="w-11 h-11 rounded-full object-cover border-2 border-slate-200 dark:border-slate-700"
                      />
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                          {athlete.name}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {athlete.position} • <span className="font-medium text-slate-700 dark:text-slate-300">{athlete.squad}</span>
                        </p>
                      </div>
                    </div>

                    <div className={`px-2.5 py-1 rounded-xl border text-xs font-extrabold flex items-center gap-1 ${readinessBadgeClass}`}>
                      {athlete.readinessScore}%
                    </div>
                  </div>

                  {/* Readiness Progress Meter */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-medium mb-1">
                      <span>Readiness Score</span>
                      {getACWRBadge(athlete.acwrStatus, athlete.currentACWR)}
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          athlete.readinessScore >= 80
                            ? 'bg-emerald-500'
                            : athlete.readinessScore >= 60
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${athlete.readinessScore}%` }}
                      />
                    </div>
                  </div>

                  {/* Survey Metrics Pills */}
                  <div className="grid grid-cols-4 gap-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px]">
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg text-center">
                      <span className="block text-slate-400 text-[10px]">Sleep</span>
                      <span className="font-bold text-slate-800 dark:text-slate-200">{athlete.sleepHours}h</span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg text-center">
                      <span className="block text-slate-400 text-[10px]">Soreness</span>
                      <span className={`font-bold ${athlete.sorenessLevel > 6 ? 'text-rose-500' : 'text-slate-800 dark:text-slate-200'}`}>
                        {athlete.sorenessLevel}/10
                      </span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg text-center">
                      <span className="block text-slate-400 text-[10px]">Fatigue</span>
                      <span className={`font-bold ${athlete.fatigueLevel > 6 ? 'text-rose-500' : 'text-slate-800 dark:text-slate-200'}`}>
                        {athlete.fatigueLevel}/10
                      </span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg text-center">
                      <span className="block text-slate-400 text-[10px]">Status</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {athlete.status}
                      </span>
                    </div>
                  </div>

                  {/* Quick Card Action Buttons */}
                  <div className="flex items-center gap-2 mt-3 pt-2">
                    <button
                      onClick={() => onOpenSurveyForAthlete(athlete.id)}
                      className="flex-1 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center justify-center gap-1 transition"
                    >
                      <ClipboardList className="w-3.5 h-3.5 text-emerald-500" />
                      Survey
                    </button>
                    <button
                      onClick={() => onOpenLogSessionForAthlete(athlete.id)}
                      className="flex-1 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center justify-center gap-1 transition"
                    >
                      <Activity className="w-3.5 h-3.5 text-teal-500" />
                      Log sRPE
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Squad Comparison Chart Column */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm h-full flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-500" />
                Readiness vs ACWR Ratio
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Bar height = Readiness % | Color = ACWR Status
              </p>

              <div className="h-64 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.3} />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                      interval={0}
                    />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '0.75rem',
                        fontSize: '12px',
                        color: '#fff'
                      }}
                    />
                    <Bar dataKey="readiness" radius={[6, 6, 0, 0]}>
                      {chartData.map((entry, idx) => {
                        const acwr = entry.acwr;
                        let color = '#10b981'; // emerald optimal
                        if (acwr > 1.5) color = '#f43f5e'; // rose spike
                        else if (acwr > 1.3) color = '#f59e0b'; // amber caution
                        else if (acwr < 0.8) color = '#64748b'; // slate underloaded
                        return <Cell key={`cell-${idx}`} fill={color} />;
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Legend */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-emerald-500" />
                <span className="text-slate-600 dark:text-slate-400">Optimal (0.8-1.3)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-amber-500" />
                <span className="text-slate-600 dark:text-slate-400">Elevated (1.3-1.5)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-rose-500" />
                <span className="text-slate-600 dark:text-slate-400">Spike (&gt;1.5)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-slate-500" />
                <span className="text-slate-600 dark:text-slate-400">Underloaded (&lt;0.8)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
