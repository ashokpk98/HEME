import React, { useState } from 'react';
import { Microcycle, Exercise, SquadName, MicrocycleDay, MicrocycleExercise, MicrocycleSet } from '../types';
import {
  Dumbbell,
  Plus,
  Trash2,
  Users,
  Sparkles,
  Calendar,
  CheckCircle2,
  Clock,
  Layers,
  ChevronDown,
  ChevronUp,
  Save,
  Search
} from 'lucide-react';

interface ProgramDesignViewProps {
  microcycles: Microcycle[];
  exercises: Exercise[];
  squads: SquadName[];
  onCreateMicrocycle: (cycle: Partial<Microcycle>) => void;
  onAssignMicrocycle: (cycleId: string, athleteIds: string[]) => void;
  onGenerateAIMicrocycle: (squad: SquadName, phase: string) => Promise<void>;
}

export const ProgramDesignView: React.FC<ProgramDesignViewProps> = ({
  microcycles,
  exercises,
  squads,
  onCreateMicrocycle,
  onAssignMicrocycle,
  onGenerateAIMicrocycle
}) => {
  const [selectedCycleId, setSelectedCycleId] = useState<string>(
    microcycles[0]?.id || ''
  );

  const activeCycle = microcycles.find(m => m.id === selectedCycleId) || microcycles[0];

  const [activeDayNumber, setActiveDayNumber] = useState<number>(1);
  const [isExerciseModalOpen, setIsExerciseModalOpen] = useState<boolean>(false);
  const [exerciseSearch, setExerciseSearch] = useState<string>('');
  const [isAIGenerating, setIsAIGenerating] = useState<boolean>(false);

  // New Microcycle Form State
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('Pre-Season Velocity Realization');
  const [newSquad, setNewSquad] = useState<SquadName>('Rugby First XV');
  const [newPhase, setNewPhase] = useState<Microcycle['focusPhase']>('Power & Speed');

  const activeDay = activeCycle?.days?.find(d => d.dayNumber === activeDayNumber) || {
    dayNumber: activeDayNumber,
    dayName: `Day ${activeDayNumber}`,
    isRestDay: false,
    exercises: [],
    estimatedSRPE: 350
  };

  const filteredExercises = exercises.filter(ex =>
    ex.name.toLowerCase().includes(exerciseSearch.toLowerCase()) ||
    ex.category.toLowerCase().includes(exerciseSearch.toLowerCase())
  );

  const handleAddExerciseToDay = (ex: Exercise) => {
    if (!activeCycle) return;

    const newEx: MicrocycleExercise = {
      id: `me-${Date.now()}`,
      exerciseId: ex.id,
      exerciseName: ex.name,
      coachingNotes: ex.cues.join(' • '),
      sets: [
        { setNumber: 1, reps: 5, intensity: '80% 1RM', targetRPE: 8, tempo: ex.defaultTempo || '3010', restSeconds: 120 },
        { setNumber: 2, reps: 5, intensity: '82.5% 1RM', targetRPE: 8.5, tempo: ex.defaultTempo || '3010', restSeconds: 120 },
        { setNumber: 3, reps: 5, intensity: '85% 1RM', targetRPE: 9, tempo: ex.defaultTempo || '3010', restSeconds: 150 },
      ]
    };

    activeDay.exercises.push(newEx);
    setIsExerciseModalOpen(false);
  };

  const handleAIGenerate = async () => {
    setIsAIGenerating(true);
    try {
      await onGenerateAIMicrocycle(newSquad, newPhase);
    } finally {
      setIsAIGenerating(false);
      setIsCreatingNew(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <Dumbbell className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-900 dark:text-white">
                Microcycle Program Design Studio
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Build 7-day training structures with set/rep/intensity schemes, velocity targets, and exercise cues
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setIsCreatingNew(!isCreatingNew)}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            New Microcycle
          </button>
        </div>
      </div>

      {/* New Microcycle Modal / Form Panel */}
      {isCreatingNew && (
        <div className="bg-gradient-to-r from-indigo-900/20 via-slate-900 to-purple-900/20 border border-indigo-500/30 rounded-2xl p-5 backdrop-blur-md space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Configure Microcycle Block
            </h3>
            <button
              onClick={() => setIsCreatingNew(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Microcycle Title
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                className="w-full text-xs font-medium bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Target Squad
              </label>
              <select
                value={newSquad}
                onChange={e => setNewSquad(e.target.value as SquadName)}
                className="w-full text-xs font-medium bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2"
              >
                {squads.map(sq => (
                  <option key={sq} value={sq}>{sq}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Focus Phase
              </label>
              <select
                value={newPhase}
                onChange={e => setNewPhase(e.target.value as Microcycle['focusPhase'])}
                className="w-full text-xs font-medium bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2"
              >
                <option value="Hypertrophy Block">Hypertrophy Block</option>
                <option value="Strength Realization">Strength Realization</option>
                <option value="Power & Speed">Power & Speed</option>
                <option value="In-Season Maintenance">In-Season Maintenance</option>
                <option value="Taper / Peak">Taper / Peak</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={handleAIGenerate}
              disabled={isAIGenerating}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white text-xs font-bold shadow-md transition flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              {isAIGenerating ? 'Generating with Gemini AI...' : 'Auto-Generate with Gemini AI'}
            </button>
            <button
              onClick={() => {
                onCreateMicrocycle({
                  title: newTitle,
                  squad: newSquad,
                  focusPhase: newPhase,
                  durationWeeks: 1,
                  assignedAthleteIds: [],
                  days: [1,2,3,4,5,6,7].map(n => ({
                    dayNumber: n,
                    dayName: `Day ${n}: ${n % 2 === 1 ? 'Training' : 'Recovery'}`,
                    isRestDay: n % 2 === 0,
                    exercises: [],
                    estimatedSRPE: n % 2 === 1 ? 400 : 0
                  }))
                });
                setIsCreatingNew(false);
              }}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md transition"
            >
              Create Blank Microcycle
            </button>
          </div>
        </div>
      )}

      {/* Main Layout: Microcycles Selector Sidebar + Day Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Microcycles List Sidebar */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-1">
            Saved Microcycles ({microcycles.length})
          </h3>

          <div className="space-y-2">
            {microcycles.map(mc => {
              const isSelected = mc.id === activeCycle?.id;
              return (
                <button
                  key={mc.id}
                  onClick={() => setSelectedCycleId(mc.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-slate-900 dark:text-white shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <div className="font-bold text-xs flex items-center justify-between">
                    <span>{mc.title}</span>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500" />}
                  </div>
                  <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-semibold">
                      {mc.focusPhase}
                    </span>
                    <span>{mc.squad}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 7-Day Microcycle Matrix Editor (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          {activeCycle && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
              {/* Active Microcycle Title & Meta */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black text-slate-900 dark:text-white">
                      {activeCycle.title}
                    </h2>
                    <span className="px-2 py-0.5 rounded text-xs font-extrabold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                      {activeCycle.focusPhase}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Squad: <strong className="text-slate-800 dark:text-slate-200">{activeCycle.squad}</strong> • Assigned Athletes: {activeCycle.assignedAthleteIds.length || 'All'}
                  </p>
                </div>
              </div>

              {/* 7-Day Tab Row */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
                {[1, 2, 3, 4, 5, 6, 7].map(dayNum => {
                  const dayObj = activeCycle.days?.find(d => d.dayNumber === dayNum);
                  const isActive = activeDayNumber === dayNum;
                  return (
                    <button
                      key={dayNum}
                      onClick={() => setActiveDayNumber(dayNum)}
                      className={`flex-1 min-w-[90px] p-2.5 rounded-xl border text-center transition ${
                        isActive
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                      }`}
                    >
                      <span className="block text-[10px] uppercase opacity-80">Day {dayNum}</span>
                      <span className="block text-xs font-bold truncate mt-0.5">
                        {dayObj?.isRestDay ? 'Rest' : `${dayObj?.exercises?.length || 0} Exercises`}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Active Day Exercises Section */}
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-indigo-500" />
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                      {activeDay.dayName || `Day ${activeDayNumber}`}
                    </h3>
                    {activeDay.isRestDay && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-500/10 text-slate-500">
                        Rest / Recovery
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => setIsExerciseModalOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-xs font-bold flex items-center gap-1 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Exercise
                  </button>
                </div>

                {/* Exercises List for Active Day */}
                {activeDay.exercises && activeDay.exercises.length > 0 ? (
                  <div className="space-y-3">
                    {activeDay.exercises.map((ex, exIdx) => (
                      <div
                        key={ex.id || exIdx}
                        className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-4 border border-slate-200 dark:border-slate-700/60 space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                              {exIdx + 1}. {ex.exerciseName}
                            </h4>
                            {ex.coachingNotes && (
                              <p className="text-xs text-indigo-600 dark:text-indigo-400 mt-0.5 font-medium">
                                Cue: {ex.coachingNotes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Sets Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs">
                            <thead>
                              <tr className="text-slate-400 text-[10px] uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                                <th className="pb-1">Set</th>
                                <th className="pb-1">Reps</th>
                                <th className="pb-1">Intensity / Load</th>
                                <th className="pb-1">Target RPE</th>
                                <th className="pb-1">Tempo</th>
                                <th className="pb-1">Rest</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200 font-medium">
                              {ex.sets.map(s => (
                                <tr key={s.setNumber}>
                                  <td className="py-1.5 font-bold text-indigo-500">#{s.setNumber}</td>
                                  <td className="py-1.5">{s.reps} reps</td>
                                  <td className="py-1.5 font-semibold text-slate-900 dark:text-white">{s.intensity}</td>
                                  <td className="py-1.5">@ RPE {s.targetRPE}</td>
                                  <td className="py-1.5 text-slate-500">{s.tempo || '3010'}</td>
                                  <td className="py-1.5 text-slate-500">{s.restSeconds}s</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 space-y-2">
                    <Dumbbell className="w-8 h-8 mx-auto opacity-50" />
                    <p className="text-xs">No exercises assigned to this day yet.</p>
                    <button
                      onClick={() => setIsExerciseModalOpen(true)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold"
                    >
                      + Add First Exercise
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Exercise Selection Modal */}
      {isExerciseModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-indigo-500" />
                Select Exercise from Library
              </h3>
              <button
                onClick={() => setIsExerciseModalOpen(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search exercise by name or category (e.g. Squat, Clean)..."
                value={exerciseSearch}
                onChange={e => setExerciseSearch(e.target.value)}
                className="w-full text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl pl-9 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2">
              {filteredExercises.map(ex => (
                <div
                  key={ex.id}
                  onClick={() => handleAddExerciseToDay(ex)}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 border border-slate-200 dark:border-slate-700/50 cursor-pointer transition flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                      {ex.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Category: {ex.category} • Muscle: {ex.primaryMuscle}
                    </p>
                  </div>
                  <Plus className="w-4 h-4 text-indigo-500" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
