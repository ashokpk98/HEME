import React, { useState } from 'react';
import { Athlete, WorkloadEntry } from '../types';
import { Activity, Clock, Flame, X, Check } from 'lucide-react';

interface LogSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  athletes: Athlete[];
  preselectedAthleteId?: string;
  onSubmitSession: (sessionData: {
    athleteId: string;
    sessionName: string;
    sessionType: WorkloadEntry['sessionType'];
    durationMinutes: number;
    rpe: number;
  }) => void;
}

export const LogSessionModal: React.FC<LogSessionModalProps> = ({
  isOpen,
  onClose,
  athletes,
  preselectedAthleteId,
  onSubmitSession
}) => {
  if (!isOpen) return null;

  const [athleteId, setAthleteId] = useState<string>(
    preselectedAthleteId || athletes[0]?.id || ''
  );
  const [sessionName, setSessionName] = useState<string>('Heavy Lower Power');
  const [sessionType, setSessionType] = useState<WorkloadEntry['sessionType']>('Strength');
  const [durationMinutes, setDurationMinutes] = useState<number>(75);
  const [rpe, setRpe] = useState<number>(8); // Borg CR10 scale (1-10)

  const computedSRPE = durationMinutes * rpe;

  const getRPEDescription = (val: number) => {
    if (val >= 10) return '10 - Maximal / All-Out Effort';
    if (val >= 9) return '9 - Extremely Hard (1 rep left)';
    if (val >= 8) return '8 - Hard (2 reps left in tank)';
    if (val >= 7) return '7 - Vigorous / Challenging';
    if (val >= 5) return '5-6 - Moderate / Aerobic Tempo';
    return '1-4 - Light / Active Recovery';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitSession({
      athleteId,
      sessionName,
      sessionType,
      durationMinutes,
      rpe
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-500">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                Log Session RPE (sRPE)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Duration (min) × Session RPE (1-10)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Athlete Selector */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Select Athlete
            </label>
            <select
              value={athleteId}
              onChange={e => setAthleteId(e.target.value)}
              className="w-full font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              {athletes.map(a => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.squad})
                </option>
              ))}
            </select>
          </div>

          {/* Session Name & Type */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Session Name
              </label>
              <input
                type="text"
                value={sessionName}
                onChange={e => setSessionName(e.target.value)}
                className="w-full font-medium bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Session Type
              </label>
              <select
                value={sessionType}
                onChange={e => setSessionType(e.target.value as WorkloadEntry['sessionType'])}
                className="w-full font-bold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="Strength">Strength</option>
                <option value="Hypertrophy">Hypertrophy</option>
                <option value="Speed & Agility">Speed & Agility</option>
                <option value="Conditioning">Conditioning</option>
                <option value="Match / Game">Match / Game</option>
                <option value="Recovery">Recovery</option>
              </select>
            </div>
          </div>

          {/* Duration Slider */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
              <span>Duration (Minutes)</span>
              <span className="text-teal-500 font-black">{durationMinutes} mins</span>
            </label>
            <input
              type="range"
              min="15"
              max="180"
              step="5"
              value={durationMinutes}
              onChange={e => setDurationMinutes(Number(e.target.value))}
              className="w-full accent-teal-500"
            />
          </div>

          {/* RPE Rating Borg Scale */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
              <span>Session RPE (1-10)</span>
              <span className="text-teal-500 font-black">RPE {rpe}</span>
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={rpe}
              onChange={e => setRpe(Number(e.target.value))}
              className="w-full accent-teal-500"
            />
            <p className="text-[11px] font-semibold text-teal-600 dark:text-teal-400 mt-1">
              {getRPEDescription(rpe)}
            </p>
          </div>

          {/* Live Calculated sRPE */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-teal-950/50 to-slate-900 border border-teal-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-extrabold uppercase text-teal-400 tracking-wider">
                Calculated Session Workload (sRPE)
              </span>
              <p className="text-[11px] text-slate-400">
                {durationMinutes} min × RPE {rpe}
              </p>
            </div>
            <div className="text-2xl font-black text-teal-400">
              {computedSRPE} <span className="text-xs text-slate-400 font-normal">AU</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-extrabold shadow-lg shadow-teal-600/20 transition flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" />
            Log sRPE Workload Entry
          </button>
        </form>
      </div>
    </div>
  );
};
