import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, ShieldAlert, Dumbbell, Activity, Check } from 'lucide-react';
import { ACWRAlert } from '../types';

interface AICoachDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  contextAlert?: ACWRAlert | null;
}

export const AICoachDrawer: React.FC<AICoachDrawerProps> = ({
  isOpen,
  onClose,
  contextAlert
}) => {
  if (!isOpen) return null;

  const [prompt, setPrompt] = useState<string>(
    contextAlert
      ? `How should I modify training load for ${contextAlert.athleteName} who currently has an ACWR spike of ${contextAlert.acwr}?`
      : 'What is the optimal velocity loss threshold for back squats during a power realization microcycle?'
  );

  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSendPrompt = async (customText?: string) => {
    const textToSend = customText || prompt;
    if (!textToSend.trim()) return;

    setIsLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/ai/coach-copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          mode: 'custom'
        })
      });

      const data = await res.json();
      if (data.response) {
        setResponse(data.response);
      } else {
        setResponse('Unable to fetch Gemini AI response at this moment.');
      }
    } catch (err) {
      console.error(err);
      setResponse('Error communicating with Gemini AI Coach endpoint.');
    } finally {
      setIsLoading(false);
    }
  };

  const presetPrompts = [
    'How to mitigate an ACWR workload spike > 1.5 without losing speed adaptions?',
    'Provide a 3-day taper microcycle for peak velocity performance.',
    'Explain the French Contrast training method for explosive athlete jump height.',
    'What wellness survey markers indicate high CNS fatigue vs peripheral muscle soreness?'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex justify-end">
      <div className="bg-slate-900 border-l border-slate-800 w-full max-w-xl h-full flex flex-col justify-between p-6 shadow-2xl space-y-4 overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-teal-500/20">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-base text-white">HEME AI Coach Copilot</h2>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Gemini 3.6 Flash
                </span>
              </div>
              <p className="text-xs text-slate-400">
                High-Performance Sports Science & Periodization Intelligence
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conversation Body */}
        <div className="flex-1 space-y-4 overflow-y-auto pr-1">
          {contextAlert && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-rose-400">
                <ShieldAlert className="w-4 h-4" />
                Active Alert Context: {contextAlert.athleteName}
              </div>
              <p>{contextAlert.message}</p>
            </div>
          )}

          {/* Preset Prompts */}
          <div>
            <span className="text-[11px] font-extrabold uppercase text-slate-500 tracking-wider block mb-2">
              Recommended Sports Science Queries
            </span>
            <div className="grid grid-cols-1 gap-2">
              {presetPrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(p);
                    handleSendPrompt(p);
                  }}
                  className="text-left p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-xs text-slate-300 transition"
                >
                  ⚡ {p}
                </button>
              ))}
            </div>
          </div>

          {/* Response Box */}
          {isLoading && (
            <div className="p-6 rounded-2xl bg-slate-800/40 border border-slate-700/50 text-center space-y-3">
              <Sparkles className="w-6 h-6 text-teal-400 animate-spin mx-auto" />
              <p className="text-xs font-bold text-teal-300">
                Analyzing workload ratios & synthesizing sports science recommendations...
              </p>
            </div>
          )}

          {response && (
            <div className="p-5 rounded-2xl bg-slate-800/80 border border-teal-500/30 text-xs text-slate-200 space-y-3 leading-relaxed shadow-lg">
              <div className="flex items-center gap-2 font-bold text-teal-400 pb-2 border-b border-slate-700">
                <Bot className="w-4 h-4" />
                HEME AI Advisory Insights
              </div>
              <div className="whitespace-pre-wrap">{response}</div>
            </div>
          )}
        </div>

        {/* Input Box */}
        <div className="pt-3 border-t border-slate-800">
          <div className="relative">
            <textarea
              rows={3}
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Ask HEME AI about ACWR ratios, velocity drops, or periodization blocks..."
              className="w-full text-xs bg-slate-800 border border-slate-700 text-white rounded-2xl p-3 pr-12 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button
              onClick={() => handleSendPrompt()}
              disabled={isLoading || !prompt.trim()}
              className="absolute right-3 bottom-4 p-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold transition disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
