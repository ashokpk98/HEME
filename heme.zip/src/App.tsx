import React, { useState, useEffect } from 'react';
import { Athlete, ACWRAlert, Microcycle, SquadName, WorkloadEntry, Exercise } from './types';
import {
  INITIAL_ATHLETES,
  INITIAL_MICROCYCLES,
  INITIAL_EXERCISES
} from './mockData';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { LoadManagementView } from './components/LoadManagementView';
import { ProgramDesignView } from './components/ProgramDesignView';
import { AthletesView } from './components/AthletesView';
import { DailySurveyModal } from './components/DailySurveyModal';
import { LogSessionModal } from './components/LogSessionModal';
import { AICoachDrawer } from './components/AICoachDrawer';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'load' | 'programs' | 'athletes'>('dashboard');
  const [selectedSquad, setSelectedSquad] = useState<SquadName | 'All'>('All');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Core Data States
  const [athletes, setAthletes] = useState<Athlete[]>(INITIAL_ATHLETES);
  const [alerts, setAlerts] = useState<ACWRAlert[]>([]);
  const [microcycles, setMicrocycles] = useState<Microcycle[]>(INITIAL_MICROCYCLES);
  const [exercises, setExercises] = useState<Exercise[]>(INITIAL_EXERCISES);

  // Navigation / Modal States
  const [isSurveyModalOpen, setIsSurveyModalOpen] = useState<boolean>(false);
  const [isLogSessionModalOpen, setIsLogSessionModalOpen] = useState<boolean>(false);
  const [isAICopilotOpen, setIsAICopilotOpen] = useState<boolean>(false);
  const [preselectedAthleteId, setPreselectedAthleteId] = useState<string | undefined>(undefined);
  const [contextAlertForCopilot, setContextAlertForCopilot] = useState<ACWRAlert | null>(null);
  const [navTargetAthleteId, setNavTargetAthleteId] = useState<string | undefined>(undefined);

  const squads: SquadName[] = [
    'Rugby First XV',
    'Track & Field',
    'Basketball Varsity',
    'Soccer Premier'
  ];

  // Sync dark mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Fetch initial data from server API
  const fetchServerData = async () => {
    try {
      const squadParam = selectedSquad !== 'All' ? `?squad=${encodeURIComponent(selectedSquad)}` : '';
      const [athRes, acwrRes, mcRes, exRes] = await Promise.all([
        fetch(`/api/athletes${squadParam}`),
        fetch('/api/acwr/overview'),
        fetch('/api/microcycles'),
        fetch('/api/exercises')
      ]);

      if (athRes.ok) {
        const athData = await athRes.json();
        if (Array.isArray(athData) && athData.length > 0) setAthletes(athData);
      }

      if (acwrRes.ok) {
        const acwrData = await acwrRes.json();
        if (acwrData.alerts) setAlerts(acwrData.alerts);
      }

      if (mcRes.ok) {
        const mcData = await mcRes.json();
        if (Array.isArray(mcData) && mcData.length > 0) setMicrocycles(mcData);
      }

      if (exRes.ok) {
        const exData = await exRes.json();
        if (Array.isArray(exData) && exData.length > 0) setExercises(exData);
      }
    } catch (err) {
      console.warn('API fetch failed, falling back to local state:', err);
    }
  };

  useEffect(() => {
    fetchServerData();
  }, [selectedSquad]);

  // Handle Daily Survey submission
  const handleSubmitSurvey = async (
    athleteId: string,
    surveyData: {
      sleepHours: number;
      sleepQuality: number;
      soreness: number;
      fatigue: number;
      stress: number;
      mood: number;
      notes?: string;
    }
  ) => {
    try {
      const res = await fetch(`/api/athletes/${athleteId}/wellness`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(surveyData)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.athlete) {
          setAthletes(prev =>
            prev.map(a => (a.id === athleteId ? data.athlete : a))
          );
        }
      }
    } catch (err) {
      console.error('Failed to submit survey:', err);
    }
  };

  // Handle sRPE Session Log submission
  const handleSubmitWorkloadSession = async (sessionData: {
    athleteId: string;
    sessionName: string;
    sessionType: WorkloadEntry['sessionType'];
    durationMinutes: number;
    rpe: number;
  }) => {
    try {
      const res = await fetch('/api/workloads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sessionData)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.athlete) {
          setAthletes(prev =>
            prev.map(a => (a.id === sessionData.athleteId ? data.athlete : a))
          );
        }
        fetchServerData(); // refresh alerts
      }
    } catch (err) {
      console.error('Failed to log workload:', err);
    }
  };

  // Handle Microcycle Creation
  const handleCreateMicrocycle = async (cycle: Partial<Microcycle>) => {
    try {
      const res = await fetch('/api/microcycles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cycle)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.microcycle) {
          setMicrocycles(prev => [data.microcycle, ...prev]);
        }
      }
    } catch (err) {
      console.error('Failed to create microcycle:', err);
    }
  };

  // Handle Microcycle Assignment
  const handleAssignMicrocycle = async (cycleId: string, athleteIds: string[]) => {
    try {
      const res = await fetch(`/api/microcycles/${cycleId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ athleteIds })
      });
      if (res.ok) {
        setMicrocycles(prev =>
          prev.map(m => (m.id === cycleId ? { ...m, assignedAthleteIds: athleteIds } : m))
        );
      }
    } catch (err) {
      console.error('Failed to assign microcycle:', err);
    }
  };

  // Handle AI Microcycle Generation
  const handleGenerateAIMicrocycle = async (squad: SquadName, phase: string) => {
    try {
      const res = await fetch('/api/ai/coach-copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Generate a 7-day microcycle training block for ${squad} focusing on ${phase}`,
          mode: 'generate_microcycle',
          contextData: { squad, focusPhase: phase }
        })
      });

      if (res.ok) {
        const data = await res.json();
        const aiText = data.response;

        // Create new generated microcycle
        const generatedCycle: Microcycle = {
          id: `mc-ai-${Date.now()}`,
          title: `AI Generated: ${phase} Block`,
          squad,
          focusPhase: phase as any,
          durationWeeks: 1,
          assignedAthleteIds: [],
          createdAt: new Date().toISOString().split('T')[0],
          days: [1, 2, 3, 4, 5, 6, 7].map(num => ({
            dayNumber: num,
            dayName: `Day ${num}: ${num % 2 === 1 ? 'Power & Speed' : 'Regeneration'}`,
            isRestDay: num % 2 === 0,
            estimatedSRPE: num % 2 === 1 ? 450 : 0,
            exercises: num % 2 === 1 ? [
              {
                id: `ex-ai-${num}-1`,
                exerciseId: 'ex-1',
                exerciseName: 'Barbell Back Squat',
                coachingNotes: 'Velocity requirement > 1.25 m/s. Stop set if drop > 10%. ' + (aiText ? aiText.slice(0, 80) : ''),
                sets: [
                  { setNumber: 1, reps: 3, intensity: '82.5% 1RM', targetRPE: 8, tempo: '3010', restSeconds: 150 },
                  { setNumber: 2, reps: 3, intensity: '85% 1RM', targetRPE: 8.5, tempo: '3010', restSeconds: 150 },
                  { setNumber: 3, reps: 2, intensity: '87.5% 1RM', targetRPE: 9, tempo: '3010', restSeconds: 180 }
                ]
              }
            ] : []
          }))
        };

        setMicrocycles(prev => [generatedCycle, ...prev]);
      }
    } catch (err) {
      console.error('Failed to generate AI microcycle:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors">
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        selectedSquad={selectedSquad}
        setSelectedSquad={setSelectedSquad}
        onOpenSurvey={() => {
          setPreselectedAthleteId(undefined);
          setIsSurveyModalOpen(true);
        }}
        onOpenLogSession={() => {
          setPreselectedAthleteId(undefined);
          setIsLogSessionModalOpen(true);
        }}
        onOpenAICopilot={() => {
          setContextAlertForCopilot(null);
          setIsAICopilotOpen(true);
        }}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'dashboard' && (
          <DashboardView
            athletes={athletes}
            alerts={alerts}
            onOpenSurveyForAthlete={id => {
              setPreselectedAthleteId(id);
              setIsSurveyModalOpen(true);
            }}
            onOpenLogSessionForAthlete={id => {
              setPreselectedAthleteId(id);
              setIsLogSessionModalOpen(true);
            }}
            onOpenAICopilotForAlert={alert => {
              setContextAlertForCopilot(alert);
              setIsAICopilotOpen(true);
            }}
            onNavigateToACWR={athId => {
              if (athId) setNavTargetAthleteId(athId);
              setCurrentTab('load');
            }}
          />
        )}

        {currentTab === 'load' && (
          <LoadManagementView
            athletes={athletes}
            selectedAthleteId={navTargetAthleteId}
            onOpenLogSession={id => {
              setPreselectedAthleteId(id);
              setIsLogSessionModalOpen(true);
            }}
            onOpenAICopilotForACWR={(athlete, acwrData) => {
              setContextAlertForCopilot({
                id: `alt-${athlete.id}`,
                athleteId: athlete.id,
                athleteName: athlete.name,
                squad: athlete.squad,
                acwr: athlete.currentACWR,
                status: athlete.acwrStatus,
                acuteLoad: Math.round(athlete.currentACWR * 500),
                chronicLoad: 500,
                message: `Current ACWR ratio is ${athlete.currentACWR}. High load spike detected over 7 days.`,
                recommendation: 'Modify next microcycle volume load.'
              });
              setIsAICopilotOpen(true);
            }}
          />
        )}

        {currentTab === 'programs' && (
          <ProgramDesignView
            microcycles={microcycles}
            exercises={exercises}
            squads={squads}
            onCreateMicrocycle={handleCreateMicrocycle}
            onAssignMicrocycle={handleAssignMicrocycle}
            onGenerateAIMicrocycle={handleGenerateAIMicrocycle}
          />
        )}

        {currentTab === 'athletes' && (
          <AthletesView
            athletes={athletes}
            squads={squads}
            onOpenSurveyForAthlete={id => {
              setPreselectedAthleteId(id);
              setIsSurveyModalOpen(true);
            }}
            onOpenLogSessionForAthlete={id => {
              setPreselectedAthleteId(id);
              setIsLogSessionModalOpen(true);
            }}
          />
        )}
      </main>

      {/* Modals & AI Copilot Drawer */}
      <DailySurveyModal
        isOpen={isSurveyModalOpen}
        onClose={() => setIsSurveyModalOpen(false)}
        athletes={athletes}
        preselectedAthleteId={preselectedAthleteId}
        onSubmitSurvey={handleSubmitSurvey}
      />

      <LogSessionModal
        isOpen={isLogSessionModalOpen}
        onClose={() => setIsLogSessionModalOpen(false)}
        athletes={athletes}
        preselectedAthleteId={preselectedAthleteId}
        onSubmitSession={handleSubmitWorkloadSession}
      />

      <AICoachDrawer
        isOpen={isAICopilotOpen}
        onClose={() => setIsAICopilotOpen(false)}
        contextAlert={contextAlertForCopilot}
      />
    </div>
  );
}
