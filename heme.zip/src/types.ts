export type SquadName = 'Rugby First XV' | 'Track & Field' | 'Basketball Varsity' | 'Soccer Premier';

export type ACWRStatus = 'Underloaded' | 'Optimal' | 'Elevated' | 'Spike';

export interface AthleteMaxes {
  squatKg: number;
  benchKg: number;
  deadliftKg: number;
  powerCleanKg: number;
}

export interface Athlete {
  id: string;
  name: string;
  squad: SquadName;
  position: string;
  avatarUrl: string;
  status: 'Active' | 'Modified' | 'Injured' | 'Resting';
  readinessScore: number; // 0-100
  currentACWR: number; // e.g. 1.15
  acwrStatus: ACWRStatus;
  sleepHours: number; // e.g. 8.2
  sorenessLevel: number; // 1-10 (1 = fresh, 10 = extreme soreness)
  fatigueLevel: number; // 1-10
  stressLevel: number; // 1-10
  moodLevel: number; // 1-10
  lastSurveyDate: string;
  maxes: AthleteMaxes;
  notes?: string;
}

export interface WellnessSurvey {
  id: string;
  athleteId: string;
  date: string;
  sleepHours: number;
  sleepQuality: number; // 1-10
  soreness: number; // 1-10
  fatigue: number; // 1-10
  stress: number; // 1-10
  mood: number; // 1-10
  readinessScore: number; // 0-100
  notes?: string;
}

export interface WorkloadEntry {
  id: string;
  athleteId: string;
  date: string;
  sessionName: string;
  sessionType: 'Strength' | 'Hypertrophy' | 'Speed & Agility' | 'Conditioning' | 'Match / Game' | 'Recovery';
  durationMinutes: number;
  rpe: number; // 1-10 Rating of Perceived Exertion
  sRPE: number; // durationMinutes * rpe
}

export interface ACWRTimelinePoint {
  date: string;
  acuteLoad: number; // 7-day rolling sum / 7
  chronicLoad: number; // 28-day rolling sum / 28
  acwr: number;
  sRPE: number;
}

export interface Exercise {
  id: string;
  name: string;
  category: 'Squat' | 'Hinge' | 'Push' | 'Pull' | 'Carry' | 'Olympic' | 'Plyometrics' | 'Conditioning';
  primaryMuscle: string;
  defaultTempo?: string;
  cues: string[];
}

export interface MicrocycleSet {
  setNumber: number;
  reps: number;
  intensity: string; // e.g., "82.5%", "75%", "RPE 8"
  targetRPE?: number;
  tempo?: string;
  restSeconds?: number;
}

export interface MicrocycleExercise {
  id: string;
  exerciseId: string;
  exerciseName: string;
  sets: MicrocycleSet[];
  coachingNotes?: string;
}

export interface MicrocycleDay {
  dayNumber: number; // 1-7
  dayName: string; // e.g., "Day 1: Max Effort Lower"
  isRestDay: boolean;
  exercises: MicrocycleExercise[];
  estimatedSRPE: number;
}

export interface Microcycle {
  id: string;
  title: string;
  squad: SquadName;
  focusPhase: 'Hypertrophy Block' | 'Strength Realization' | 'Power & Speed' | 'In-Season Maintenance' | 'Taper / Peak';
  durationWeeks: number;
  days: MicrocycleDay[];
  assignedAthleteIds: string[];
  createdAt: string;
}

export interface ACWRAlert {
  id: string;
  athleteId: string;
  athleteName: string;
  squad: SquadName;
  acwr: number;
  status: ACWRStatus;
  acuteLoad: number;
  chronicLoad: number;
  message: string;
  recommendation: string;
}

export interface CoachAICoachResponse {
  insights: string[];
  recommendedAdjustments: {
    athleteId: string;
    athleteName: string;
    action: string;
    reason: string;
  }[];
  summaryMarkdown: string;
}
