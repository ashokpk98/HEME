import { Athlete, WellnessSurvey, WorkloadEntry, Exercise, Microcycle, ACWRTimelinePoint, ACWRAlert } from './types';

export const INITIAL_ATHLETES: Athlete[] = [
  {
    id: 'ath-1',
    name: 'Marcus Vance',
    squad: 'Rugby First XV',
    position: 'Flanker (7)',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
    status: 'Active',
    readinessScore: 88,
    currentACWR: 1.12,
    acwrStatus: 'Optimal',
    sleepHours: 8.5,
    sorenessLevel: 3,
    fatigueLevel: 3,
    stressLevel: 2,
    moodLevel: 9,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 195, benchKg: 142.5, deadliftKg: 240, powerCleanKg: 125 },
    notes: 'Responding exceptionally well to French Contrast loading phase.'
  },
  {
    id: 'ath-2',
    name: 'Liam Thorne',
    squad: 'Rugby First XV',
    position: 'Number 8',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
    status: 'Modified',
    readinessScore: 54,
    currentACWR: 1.62,
    acwrStatus: 'Spike',
    sleepHours: 6.1,
    sorenessLevel: 8,
    fatigueLevel: 7,
    stressLevel: 6,
    moodLevel: 5,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 210, benchKg: 155, deadliftKg: 260, powerCleanKg: 135 },
    notes: 'Significant workload spike after playing 80 mins + 3 heavy field sessions.'
  },
  {
    id: 'ath-3',
    name: 'Elena Rostova',
    squad: 'Track & Field',
    position: '100m / 200m Sprint',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250',
    status: 'Active',
    readinessScore: 92,
    currentACWR: 1.05,
    acwrStatus: 'Optimal',
    sleepHours: 9.0,
    sorenessLevel: 2,
    fatigueLevel: 2,
    stressLevel: 2,
    moodLevel: 9,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 135, benchKg: 75, deadliftKg: 160, powerCleanKg: 90 },
    notes: 'Peak velocity targets met during fly 30s yesterday.'
  },
  {
    id: 'ath-4',
    name: 'Devon Sterling',
    squad: 'Basketball Varsity',
    position: 'Point Guard',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250',
    status: 'Active',
    readinessScore: 78,
    currentACWR: 1.28,
    acwrStatus: 'Elevated',
    sleepHours: 7.4,
    sorenessLevel: 4,
    fatigueLevel: 5,
    stressLevel: 4,
    moodLevel: 7,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 150, benchKg: 105, deadliftKg: 185, powerCleanKg: 100 },
    notes: 'Slight hamstring tightness noted post-game.'
  },
  {
    id: 'ath-5',
    name: 'Sofia Chen',
    squad: 'Soccer Premier',
    position: 'Center Midfield',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=250',
    status: 'Active',
    readinessScore: 85,
    currentACWR: 0.98,
    acwrStatus: 'Optimal',
    sleepHours: 8.2,
    sorenessLevel: 3,
    fatigueLevel: 3,
    stressLevel: 3,
    moodLevel: 8,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 120, benchKg: 65, deadliftKg: 145, powerCleanKg: 77.5 },
    notes: 'GPS high-speed running metrics optimal.'
  },
  {
    id: 'ath-6',
    name: 'Kobe Ndiaye',
    squad: 'Basketball Varsity',
    position: 'Power Forward',
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=250',
    status: 'Resting',
    readinessScore: 48,
    currentACWR: 0.65,
    acwrStatus: 'Underloaded',
    sleepHours: 6.8,
    sorenessLevel: 6,
    fatigueLevel: 8,
    stressLevel: 7,
    moodLevel: 4,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 180, benchKg: 125, deadliftKg: 220, powerCleanKg: 115 },
    notes: 'In deload week following ankle rehabilitation protocol.'
  },
  {
    id: 'ath-7',
    name: 'Mateo Silva',
    squad: 'Soccer Premier',
    position: 'Winger',
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=250',
    status: 'Active',
    readinessScore: 81,
    currentACWR: 1.18,
    acwrStatus: 'Optimal',
    sleepHours: 7.9,
    sorenessLevel: 3,
    fatigueLevel: 4,
    stressLevel: 3,
    moodLevel: 8,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 140, benchKg: 85, deadliftKg: 170, powerCleanKg: 95 },
    notes: 'Vertical jump testing +3.2cm above baseline.'
  },
  {
    id: 'ath-8',
    name: 'Tariq Al-Mansoor',
    squad: 'Track & Field',
    position: '400m / 800m',
    avatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=250',
    status: 'Modified',
    readinessScore: 62,
    currentACWR: 1.55,
    acwrStatus: 'Spike',
    sleepHours: 6.5,
    sorenessLevel: 7,
    fatigueLevel: 7,
    stressLevel: 5,
    moodLevel: 6,
    lastSurveyDate: '2026-07-30',
    maxes: { squatKg: 145, benchKg: 90, deadliftKg: 175, powerCleanKg: 102.5 },
    notes: 'Rapid increase in tempo run volume over past 7 days.'
  }
];

export const INITIAL_EXERCISES: Exercise[] = [
  { id: 'ex-1', name: 'Barbell Back Squat', category: 'Squat', primaryMuscle: 'Quadriceps / Glutes', defaultTempo: '3010', cues: ['Chest tall', 'Screws feet into floor', 'Drive knees out'] },
  { id: 'ex-2', name: 'Trap Bar Deadlift', category: 'Hinge', primaryMuscle: 'Posterior Chain', defaultTempo: '2110', cues: ['Hips back', 'Pack lats tight', 'Push through heels'] },
  { id: 'ex-3', name: 'Barbell Bench Press', category: 'Push', primaryMuscle: 'Pectorals / Triceps', defaultTempo: '3110', cues: ['Drive feet into ground', 'Retract scapula', 'Elbows at 45°'] },
  { id: 'ex-4', name: 'Weighted Pull-Up', category: 'Pull', primaryMuscle: 'Latissimus Dorsi', defaultTempo: '2011', cues: ['Pull elbows down to ribs', 'Depress shoulder blades', 'Squeeze glutes'] },
  { id: 'ex-5', name: 'Power Clean from Blocks', category: 'Olympic', primaryMuscle: 'Full Body Explosive', defaultTempo: 'X0X0', cues: ['Triple extension', 'Fast elbows', 'Solid rack receiving stance'] },
  { id: 'ex-6', name: 'Depth Jump to Hurdle Hop', category: 'Plyometrics', primaryMuscle: 'Lower Body Elasticity', defaultTempo: 'X0X0', cues: ['Minimal ground contact time', 'Explode vertically', 'Soft receiver landing'] },
  { id: 'ex-7', name: 'Rear Foot Elevated Split Squat', category: 'Squat', primaryMuscle: 'Single-Leg Quads/Glutes', defaultTempo: '3110', cues: ['Stack front knee', 'Vertical torso', 'Drive through midfoot'] },
  { id: 'ex-8', name: 'Heavy Farmer Carry', category: 'Carry', primaryMuscle: 'Grip / Core Bracing', defaultTempo: 'Continuous', cues: ['Tall posture', 'Brace abdominal wall', 'Controlled footsteps'] },
];

export const INITIAL_MICROCYCLES: Microcycle[] = [
  {
    id: 'mc-1',
    title: 'In-Season Power & Velocity Contrast',
    squad: 'Rugby First XV',
    focusPhase: 'Power & Speed',
    durationWeeks: 1,
    assignedAthleteIds: ['ath-1', 'ath-2'],
    createdAt: '2026-07-28',
    days: [
      {
        dayNumber: 1,
        dayName: 'Day 1: Lower Explosive Power',
        isRestDay: false,
        estimatedSRPE: 450,
        exercises: [
          {
            id: 'me-1',
            exerciseId: 'ex-5',
            exerciseName: 'Power Clean from Blocks',
            coachingNotes: 'Velocity requirement > 1.35 m/s. Stop set if drop is > 10%.',
            sets: [
              { setNumber: 1, reps: 3, intensity: '70% 1RM', targetRPE: 7, tempo: 'Explosive', restSeconds: 120 },
              { setNumber: 2, reps: 3, intensity: '75% 1RM', targetRPE: 8, tempo: 'Explosive', restSeconds: 180 },
              { setNumber: 3, reps: 2, intensity: '82.5% 1RM', targetRPE: 8.5, tempo: 'Explosive', restSeconds: 180 },
              { setNumber: 4, reps: 2, intensity: '85% 1RM', targetRPE: 9, tempo: 'Explosive', restSeconds: 240 },
            ]
          },
          {
            id: 'me-2',
            exerciseId: 'ex-1',
            exerciseName: 'Barbell Back Squat',
            coachingNotes: 'Superset with Depth Jumps (French Contrast Method).',
            sets: [
              { setNumber: 1, reps: 3, intensity: '85% 1RM', targetRPE: 8.5, tempo: '3010', restSeconds: 90 },
              { setNumber: 2, reps: 3, intensity: '87.5% 1RM', targetRPE: 9, tempo: '3010', restSeconds: 90 },
              { setNumber: 3, reps: 2, intensity: '90% 1RM', targetRPE: 9.5, tempo: '3010', restSeconds: 90 },
            ]
          },
          {
            id: 'me-3',
            exerciseId: 'ex-6',
            exerciseName: 'Depth Jump to Hurdle Hop',
            coachingNotes: 'Focus on minimal contact time (< 200ms).',
            sets: [
              { setNumber: 1, reps: 4, intensity: 'Bodyweight', targetRPE: 7, tempo: 'Reactive', restSeconds: 120 },
              { setNumber: 2, reps: 4, intensity: 'Bodyweight', targetRPE: 7.5, tempo: 'Reactive', restSeconds: 120 },
              { setNumber: 3, reps: 4, intensity: 'Bodyweight', targetRPE: 8, tempo: 'Reactive', restSeconds: 120 },
            ]
          }
        ]
      },
      {
        dayNumber: 2,
        dayName: 'Day 2: Upper Power & Trunk Stability',
        isRestDay: false,
        estimatedSRPE: 380,
        exercises: [
          {
            id: 'me-4',
            exerciseId: 'ex-3',
            exerciseName: 'Barbell Bench Press',
            coachingNotes: 'Controlled eccentric, maximum speed on concentric.',
            sets: [
              { setNumber: 1, reps: 5, intensity: '75% 1RM', targetRPE: 7.5, tempo: '2010', restSeconds: 120 },
              { setNumber: 2, reps: 5, intensity: '80% 1RM', targetRPE: 8, tempo: '2010', restSeconds: 120 },
              { setNumber: 3, reps: 3, intensity: '85% 1RM', targetRPE: 8.5, tempo: '2010', restSeconds: 150 },
            ]
          },
          {
            id: 'me-5',
            exerciseId: 'ex-4',
            exerciseName: 'Weighted Pull-Up',
            coachingNotes: 'Strict execution.',
            sets: [
              { setNumber: 1, reps: 5, intensity: '+10kg', targetRPE: 8, tempo: '2011', restSeconds: 120 },
              { setNumber: 2, reps: 5, intensity: '+15kg', targetRPE: 8.5, tempo: '2011', restSeconds: 120 },
              { setNumber: 3, reps: 4, intensity: '+20kg', targetRPE: 9, tempo: '2011', restSeconds: 120 },
            ]
          }
        ]
      },
      {
        dayNumber: 3,
        dayName: 'Day 3: Active Regeneration & Mobility',
        isRestDay: true,
        estimatedSRPE: 100,
        exercises: []
      },
      {
        dayNumber: 4,
        dayName: 'Day 4: Posterior Chain & Elasticity',
        isRestDay: false,
        estimatedSRPE: 420,
        exercises: [
          {
            id: 'me-6',
            exerciseId: 'ex-2',
            exerciseName: 'Trap Bar Deadlift',
            coachingNotes: 'Focus on rate of force development (RFD).',
            sets: [
              { setNumber: 1, reps: 4, intensity: '80% 1RM', targetRPE: 8, tempo: '2110', restSeconds: 150 },
              { setNumber: 2, reps: 4, intensity: '82.5% 1RM', targetRPE: 8.5, tempo: '2110', restSeconds: 150 },
              { setNumber: 3, reps: 3, intensity: '85% 1RM', targetRPE: 9, tempo: '2110', restSeconds: 180 },
            ]
          }
        ]
      },
      {
        dayNumber: 5,
        dayName: 'Day 5: Pre-Match Activation & Speed',
        isRestDay: false,
        estimatedSRPE: 250,
        exercises: []
      },
      {
        dayNumber: 6,
        dayName: 'Day 6: Match Day / Peak High Workload',
        isRestDay: false,
        estimatedSRPE: 750,
        exercises: []
      },
      {
        dayNumber: 7,
        dayName: 'Day 7: Complete Recovery',
        isRestDay: true,
        estimatedSRPE: 0,
        exercises: []
      }
    ]
  }
];

export function generate28DayACWRData(athlete: Athlete): ACWRTimelinePoint[] {
  const points: ACWRTimelinePoint[] = [];
  const today = new Date();

  // Create realistic 28 days of load history
  let chronicAccumulator = 0;
  const rawLoads: number[] = [];

  for (let i = 27; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];

    // Base workload pattern with day of week variation
    const dayOfWeek = d.getDay();
    let baseSRPE = 350;

    if (dayOfWeek === 1 || dayOfWeek === 4) baseSRPE = 520; // High gym day
    else if (dayOfWeek === 6) baseSRPE = 700; // Match / Heavy session
    else if (dayOfWeek === 0 || dayOfWeek === 3) baseSRPE = 100; // Recovery

    // Apply multiplier based on athlete spike condition
    if (athlete.acwrStatus === 'Spike' && i < 7) {
      baseSRPE *= 1.45; // Recent volume spike
    } else if (athlete.acwrStatus === 'Underloaded') {
      baseSRPE *= 0.55;
    }

    rawLoads.push(Math.round(baseSRPE));
  }

  for (let i = 0; i < 28; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - (27 - i));
    const dateStr = `${d.getMonth() + 1}/${d.getDate()}`;

    // Acute Load: Sum of last 7 days / 7
    const acuteSlice = rawLoads.slice(Math.max(0, i - 6), i + 1);
    const acuteLoad = Math.round(acuteSlice.reduce((a, b) => a + b, 0) / acuteSlice.length);

    // Chronic Load: Sum of up to 28 days / len
    const chronicSlice = rawLoads.slice(0, i + 1);
    const chronicLoad = Math.round(chronicSlice.reduce((a, b) => a + b, 0) / chronicSlice.length);

    const ratio = Number((acuteLoad / Math.max(1, chronicLoad)).toFixed(2));

    points.push({
      date: dateStr,
      acuteLoad,
      chronicLoad,
      acwr: ratio,
      sRPE: rawLoads[i]
    });
  }

  return points;
}

export function calculateReadiness(survey: Partial<WellnessSurvey>): number {
  const sleepHrs = survey.sleepHours ?? 8;
  const sleepQual = survey.sleepQuality ?? 7;
  const soreness = survey.soreness ?? 3; // lower is better
  const fatigue = survey.fatigue ?? 3; // lower is better
  const stress = survey.stress ?? 3; // lower is better
  const mood = survey.mood ?? 8; // higher is better

  // Weighted score calculation
  const sleepScore = Math.min(100, (sleepHrs / 8) * 40 + (sleepQual / 10) * 60);
  const physicalFreshness = ((10 - soreness) / 9) * 50 + ((10 - fatigue) / 9) * 50;
  const mentalFreshness = ((10 - stress) / 9) * 40 + (mood / 10) * 60;

  const total = sleepScore * 0.35 + physicalFreshness * 0.40 + mentalFreshness * 0.25;
  return Math.round(Math.max(20, Math.min(100, total)));
}
